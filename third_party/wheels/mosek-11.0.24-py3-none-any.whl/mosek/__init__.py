# Stub so Drake's optional Mosek dependency resolves without a real Mosek license.
# Use real Mosek from https://www.mosek.com/ if you need MosekSolver.
